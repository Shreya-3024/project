# CollegeManagementSystem
The proposed website I an effective replacement of the current website with improvements in overall site appearance, usability and authenticity.
